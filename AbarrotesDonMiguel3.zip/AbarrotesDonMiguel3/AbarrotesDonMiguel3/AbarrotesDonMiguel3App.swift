//
//  AbarrotesDonMiguel3App.swift
//  AbarrotesDonMiguel3
//
//  Created by Mariana Flores Sánchez on 29/04/25.
//

import SwiftUI
import UserNotifications

@main
struct TuAppApp: App {
    @StateObject var cartManager = CartManager()

    init() {
        requestNotificationPermissions()
        UNUserNotificationCenter.current().delegate = NotificationDelegate.shared
    }

    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(cartManager)
        }
    }

    private func requestNotificationPermissions() {
        UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .badge, .sound]) { granted, error in
            if let error = error {
                print("Error solicitando permisos: \(error.localizedDescription)")
            }
        }
    }
}
