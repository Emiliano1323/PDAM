//
//  MainMenuView.swift
//  AbarrotesDonMiguel3
//
//  Created by Mariana Flores Sánchez on 29/04/25.
//
import SwiftUI

struct MainMenuView: View {
    var body: some View {
        VStack(spacing: 30) {
            Text("Bienvenido a Abarrotes Don Miguel")
                .font(.title)
                .fontWeight(.bold)
                .padding(.top, 30)

            NavigationLink("Ver productos", destination: ProductListView())
                .fontWeight(.bold)
                .frame(width: 250, height: 50)
                .background(Color.blue)
                .foregroundColor(.white)
                .cornerRadius(10)
                .padding(.top, 10)

            NavigationLink("Ver carrito", destination: CartView())
                .fontWeight(.bold)
                .frame(width: 250, height: 50)
                .background(Color.orange)
                .foregroundColor(.white)
                .cornerRadius(10)
                .padding(.top, 10)

            NavigationLink("Historial de compras", destination: PurchaseHistoryView())
                .fontWeight(.bold)
                .frame(width: 250, height: 50)
                .background(Color.green)
                .foregroundColor(.white)
                .cornerRadius(10)
                .padding(.top, 10)
        }
        .padding()
        .navigationTitle("Menú Principal")
    }
}
