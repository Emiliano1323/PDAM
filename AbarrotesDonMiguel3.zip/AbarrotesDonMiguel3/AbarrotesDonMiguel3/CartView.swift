//
//  CartView.swift
//  AbarrotesDonMiguel3
//
//  Created by Mariana Flores Sánchez on 29/04/25.
//
import SwiftUI

struct CartView: View {
    @EnvironmentObject var cartManager: CartManager
    @State private var showSuccess = false

    var body: some View {
        VStack {
            if cartManager.cart.isEmpty {
                Text("Carrito vacío").padding()
            } else {
                List {
                    ForEach(cartManager.cart, id: \.self) { product in
                        HStack {
                            Text(product.name)
                            Spacer()
                            Text(String(format: "$%.2f", product.price))
                        }
                    }
                }
                Text("Total: $\(cartManager.total(), specifier: "%.2f")")
                    .bold()
                    .padding()

                Button("Finalizar compra") {
                    cartManager.finalizePurchase()
                    showSuccess = true
                }
                .alert(isPresented: $showSuccess) {
                    Alert(title: Text("Compra realizada"), message: Text("Gracias por su compra"), dismissButton: .default(Text("OK")))
                }
                .padding()
            }
        }
        .navigationTitle("Carrito")
    }
}

