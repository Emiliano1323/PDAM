//
//  CartManager.swift
//  AbarrotesDonMiguel3
//
//  Created by Mariana Flores Sánchez on 29/04/25.
//
import Foundation
import UserNotifications

// Ahora CartProduct implementa Hashable para solucionar el problema con ForEach.
struct CartProduct: Identifiable, Equatable, Hashable {
    let id = UUID()
    let name: String
    let price: Double
    let imageName: String
}

struct CartPurchase: Identifiable {
    let id = UUID()
    let date: Date
    let items: [CartProduct]
    let total: Double
}

class CartManager: ObservableObject {
    @Published var cart: [CartProduct] = []
    @Published var history: [CartPurchase] = []

    func addToCart(_ product: CartProduct) {
        cart.append(product)
    }

    func removeFromCart(_ product: CartProduct) {
        if let index = cart.firstIndex(of: product) {
            cart.remove(at: index)
        }
    }

    func total() -> Double {
        cart.reduce(0) { $0 + $1.price }
    }

    func finalizePurchase() {
        guard !cart.isEmpty else { return }

        let purchase = CartPurchase(date: Date(), items: cart, total: total())
        history.append(purchase)
        cart.removeAll()

        sendPurchaseNotification()
    }

    private func sendPurchaseNotification() {
        let content = UNMutableNotificationContent()
        content.title = "Compra realizada"
        content.body = "¡Gracias por tu compra en Abarrotes Don Miguel!"
        content.sound = .default

        let trigger = UNTimeIntervalNotificationTrigger(timeInterval: 1, repeats: false)
        let request = UNNotificationRequest(identifier: UUID().uuidString, content: content, trigger: trigger)

        UNUserNotificationCenter.current().add(request) { error in
            if let error = error {
                print("Error al enviar la notificación: \(error.localizedDescription)")
            }
        }
    }
}
