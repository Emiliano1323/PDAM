//
//  ProductListView.swift
//  AbarrotesDonMiguel3
//
//  Created by Mariana Flores Sánchez on 29/04/25.
//
import SwiftUI

struct ProductListView: View {
    @EnvironmentObject var cartManager: CartManager

    let products = [
        CartProduct(name: "Arroz", price: 25, imageName: "arroz"),
        CartProduct(name: "Frijol", price: 30, imageName: "frijol"),
        CartProduct(name: "Aceite", price: 50, imageName: "aceite"),
        CartProduct(name: "Papel higiénico", price: 40, imageName: "papel_higienico")
    ]

    var body: some View {
        List {
            ForEach(products) { product in
                HStack {
                    Image(product.imageName)
                        .resizable()
                        .scaledToFit()
                        .frame(width: 50, height: 50)
                        .cornerRadius(10)

                    VStack(alignment: .leading) {
                        Text(product.name)
                            .font(.headline)
                        Text(String(format: "$%.2f", product.price))
                            .font(.subheadline)
                            .foregroundColor(.gray)
                    }

                    Spacer()

                    Button("Agregar") {
                        cartManager.addToCart(product)
                    }
                    .padding(10)
                    .background(Color.green)
                    .foregroundColor(.white)
                    .cornerRadius(10)
                }
                .padding(.vertical, 5)
            }
        }
        .navigationTitle("Productos")
        .padding()
    }
}
