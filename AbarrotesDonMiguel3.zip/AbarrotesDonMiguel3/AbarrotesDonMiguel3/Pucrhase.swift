//
//  Pucrhase.swift
//  AbarrotesDonMiguel3
//
//  Created by Mariana Flores Sánchez on 29/04/25.
//
import Foundation

struct Purchase: Identifiable {
    let id = UUID()
    let date: Date
    let items: [Product]
    let total: Double
}

