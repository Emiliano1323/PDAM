//
//  LoginView.swift
//  AbarrotesDonMiguel3
//
//  Created by Mariana Flores Sánchez on 29/04/25.
//
import SwiftUI

struct LoginView: View {
    @State private var username = ""
    @State private var password = ""
    @State private var showError = false
    @State private var isLoggedIn = false

    let validUsers = [
        User(username: "admin1234@gmail.com", password: "1234"),
        User(username: "demo", password: "demo")
    ]

    var body: some View {
        NavigationView {
            VStack(spacing: 30) {
                Text("Abarrotes Don Miguel")
                    .font(.largeTitle)
                    .fontWeight(.bold)
                    .foregroundColor(.primary)
                    .padding(.top, 50)

                VStack(alignment: .leading, spacing: 15) {
                    TextField("Usuario", text: $username)
                        .padding()
                        .background(Color(UIColor.systemGray6))
                        .cornerRadius(10)
                        .autocapitalization(.none)

                    SecureField("Contraseña", text: $password)
                        .padding()
                        .background(Color(UIColor.systemGray6))
                        .cornerRadius(10)
                }
                .padding(.horizontal)

                if showError {
                    Text("Usuario o contraseña incorrectos")
                        .foregroundColor(.red)
                        .padding(.top, 5)
                }

                Button(action: {
                    if validUsers.contains(where: { $0.username == username && $0.password == password }) {
                        isLoggedIn = true
                    } else {
                        showError = true
                    }
                }) {
                    Text("Iniciar sesión")
                        .fontWeight(.bold)
                        .frame(width: 250, height: 50)
                        .background(Color.blue)
                        .foregroundColor(.white)
                        .cornerRadius(10)
                }

                NavigationLink("", destination: MainMenuView(), isActive: $isLoggedIn)
                    .hidden()
            }
            .padding()
            .navigationTitle("Iniciar Sesión")
        }
    }
}
