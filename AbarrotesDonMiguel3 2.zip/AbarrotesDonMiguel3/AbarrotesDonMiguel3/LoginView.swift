//
//  LoginView.swift
//  AbarrotesDonMiguel3
//
//  Created by Mariana Flores Sánchez on 29/04/25.
//
import SwiftUI

struct LoginView: View {
    @State private var username = ""
    @State private var password = ""
    @State private var isPasswordVisible = false
    @State private var isLoggingIn = false
    @State private var showAlert = false

    // Credenciales válidas
    let validUsername = "admin1234@gmail.com"
    let validPassword = "1234"

    var body: some View {
        NavigationView {
            ZStack {
                LinearGradient(gradient: Gradient(colors: [Color.yellow.opacity(0.3), Color.red.opacity(0.3)]),
                               startPoint: .top,
                               endPoint: .bottom)
                    .ignoresSafeArea()

                VStack(spacing: 20) {
                    Spacer()

                    Text("¡Bienvenido a Abarrotes Don Miguel!")
                        .font(.largeTitle)
                        .fontWeight(.bold)
                        .multilineTextAlignment(.center)
                        .foregroundColor(.black)
                        .padding(.horizontal)

                    Text("Abarrotes Don Miguel")
                        .font(.title2)
                        .foregroundColor(.gray)

                    Spacer()

                    VStack(spacing: 16) {
                        TextField("Usuario", text: $username)
                            .padding()
                            .background(Color.white)
                            .cornerRadius(12)
                            .shadow(radius: 3)
                            .foregroundColor(.black)
                            .autocapitalization(.none)
                            .padding(.horizontal)

                        HStack {
                            Group {
                                if isPasswordVisible {
                                    TextField("Contraseña", text: $password)
                                } else {
                                    SecureField("Contraseña", text: $password)
                                }
                            }
                            .foregroundColor(.black)

                            Button(action: {
                                isPasswordVisible.toggle()
                            }) {
                                Image(systemName: isPasswordVisible ? "eye.slash.fill" : "eye.fill")
                                    .foregroundColor(.gray)
                            }
                        }
                        .padding()
                        .background(Color.white)
                        .cornerRadius(12)
                        .shadow(radius: 3)
                        .padding(.horizontal)

                        // Botón de inicio de sesión
                        Button(action: {
                            if username == validUsername && password == validPassword {
                                isLoggingIn = true
                            } else {
                                showAlert = true
                            }
                        }) {
                            Text("Iniciar sesión")
                                .font(.headline)
                                .foregroundColor(.black)
                                .frame(maxWidth: .infinity)
                                .padding()
                                .background(Color.white)
                                .overlay(
                                    RoundedRectangle(cornerRadius: 10)
                                        .stroke(Color.black, lineWidth: 2)
                                )
                                .cornerRadius(10)
                                .shadow(radius: 4)
                        }
                        .padding(.horizontal)

                        // Navegación al menú si las credenciales son correctas
                        NavigationLink(destination: MainMenuView(), isActive: $isLoggingIn) {
                            EmptyView()
                        }
                    }

                    Spacer()
                }
            }
            .alert(isPresented: $showAlert) {
                Alert(title: Text("Error"),
                      message: Text("Usuario o contraseña incorrectos"),
                      dismissButton: .default(Text("OK")))
            }
        }
    }
}

struct LoginView_Previews: PreviewProvider {
    static var previews: some View {
        LoginView()
    }
}
