//
//  MainMenuView.swift
//  AbarrotesDonMiguel3
//
//  Created by Mariana Flores Sánchez on 29/04/25.
//
import SwiftUI

struct MainMenuView: View {
    var body: some View {
        ZStack {
            LinearGradient(gradient: Gradient(colors: [Color.yellow.opacity(0.3), Color.red.opacity(0.3)]),
                           startPoint: .top,
                           endPoint: .bottom)
                .ignoresSafeArea()

            VStack(spacing: 30) {
                Text("¡Bienvenido a Abarrotes Don Miguel!")
                    .font(.largeTitle)
                    .fontWeight(.bold)
                    .foregroundColor(Color("MexicanRed"))
                    .padding(.top, 30)
                
                // Slogan atractivo
                Text("En Abarrotes Don Miguel, cada producto te acerca más a tu hogar.")
                    .font(.title3)
                    .foregroundColor(.primary)
                    .italic()
                    .padding(.horizontal, 20)

                NavigationLink("Ver productos", destination: ProductListView())
                    .buttonStyle(PrimaryButtonStyle())
                    .padding(.top, 10)

                NavigationLink("Ver carrito", destination: CartView())
                    .buttonStyle(PrimaryButtonStyle())
                    .padding(.top, 10)

                NavigationLink("Historial de compras", destination: PurchaseHistoryView())
                    .buttonStyle(PrimaryButtonStyle())
                    .padding(.top, 10)

                NavigationLink("Administrar inventario", destination: InventoryManagementView())
                    .buttonStyle(PrimaryButtonStyle())
                    .padding(.top, 10)
            }
            .padding()
            .background(Color("lightYellow"))
            .cornerRadius(15)
            .shadow(radius: 10)
        }
    }
}
