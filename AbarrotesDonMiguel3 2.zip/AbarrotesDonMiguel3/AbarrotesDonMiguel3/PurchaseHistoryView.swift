//
//  PurchaseHistoryView.swift
//  AbarrotesDonMiguel3
//
//  Created by Mariana Flores Sánchez on 29/04/25.
//
import SwiftUI

struct PurchaseHistoryView: View {
    @EnvironmentObject var cartManager: CartManager

    var body: some View {
        ZStack {
            LinearGradient(gradient: Gradient(colors: [Color.yellow.opacity(0.3), Color.red.opacity(0.3)]),
                           startPoint: .top,
                           endPoint: .bottom)
                .ignoresSafeArea()

            List {
                if cartManager.history.isEmpty {
                    Text("No hay compras registradas")
                        .font(.body)
                        .foregroundColor(.gray)
                } else {
                    ForEach(cartManager.history) { purchase in
                        VStack(alignment: .leading) {
                            Text("Compra del \(purchase.date, formatter: dateFormatter)")
                                .font(.headline)
                            ForEach(purchase.items, id: \.self) { product in
                                Text("- \(product.name)")
                                    .font(.body)
                                    .padding(.leading)
                            }
                            Text("Total: $\(purchase.total, specifier: "%.2f")")
                                .bold()
                                .padding(.top, 2)
                        }
                        .padding(.vertical, 5)
                    }
                }
            }
            .navigationTitle("Historial de Compras")
            .padding()
        }
    }
}

private let dateFormatter: DateFormatter = {
    let df = DateFormatter()
    df.dateStyle = .medium
    df.timeStyle = .short
    return df
}()
