//
//  ProductListView.swift
//  AbarrotesDonMiguel3
//
//  Created by Mariana Flores Sánchez on 29/04/25.
//
import SwiftUI

struct ProductListView: View {
    @EnvironmentObject var cartManager: CartManager
    @EnvironmentObject var inventoryManager: InventoryManager
    @State private var searchText = "" // State para el texto de búsqueda

    var filteredProducts: [CartProduct] {
        // Filtra los productos según el texto de búsqueda
        if searchText.isEmpty {
            return inventoryManager.products
        } else {
            return inventoryManager.products.filter { product in
                product.name.lowercased().contains(searchText.lowercased())
            }
        }
    }

    var body: some View {
        ZStack {
            LinearGradient(gradient: Gradient(colors: [Color.yellow.opacity(0.3), Color.red.opacity(0.3)]),
                           startPoint: .top,
                           endPoint: .bottom)
                .ignoresSafeArea()

            VStack {
                // Filtro de búsqueda
                TextField("Buscar productos", text: $searchText)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                    .padding()
                    .background(Color.white)
                    .cornerRadius(8)
                    .padding(.horizontal)

                ScrollView {
                    VStack(spacing: 20) {
                        ForEach(filteredProducts) { product in
                            HStack {
                                Image(product.imageName)
                                    .resizable()
                                    .scaledToFit()
                                    .frame(width: 80, height: 80)
                                    .cornerRadius(15)

                                VStack(alignment: .leading, spacing: 10) {
                                    Text(product.name)
                                        .font(.title2)
                                        .fontWeight(.bold)
                                        .foregroundColor(.primary)

                                    Text(String(format: "$%.2f", product.price))
                                        .font(.subheadline)
                                        .foregroundColor(.secondary)
                                }

                                Spacer()

                                Button("Agregar al carrito") {
                                    cartManager.addToCart(product)
                                }
                                .buttonStyle(PrimaryButtonStyle())
                                .padding(10)
                                .background(Color("MexicanRed"))
                                .foregroundColor(.white)
                                .cornerRadius(10)
                                .shadow(radius: 5)
                            }
                            .padding()
                            .background(Color("lightGreen"))
                            .cornerRadius(15)
                            .shadow(radius: 5)
                        }
                    }
                    .padding()
                }
            }
            .navigationTitle("Productos")
            .background(Color("lightYellow"))
            .cornerRadius(20)
            .shadow(radius: 10)
        }
    }
}
