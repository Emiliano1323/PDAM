//
//  PrimaryButtonStyle.swift
//  AbarrotesDonMiguel3
//
//  Created by Mariana Flores Sánchez on 04/05/25.
//
import SwiftUI

struct PrimaryButtonStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .padding()
            .background(
                RoundedRectangle(cornerRadius: 10)
                    .stroke(Color.white, lineWidth: 2) // Borde blanco
                    .background(
                        configuration.isPressed ? Color("MexicanRed").opacity(0.8) : Color.clear // Cambia el color de fondo al presionar
                    )
            )
            .foregroundColor(.white)
            .cornerRadius(10)
            .shadow(radius: 5)
            .scaleEffect(configuration.isPressed ? 0.95 : 1) // Efecto de presión
            .animation(.spring(), value: configuration.isPressed)
    }
}
