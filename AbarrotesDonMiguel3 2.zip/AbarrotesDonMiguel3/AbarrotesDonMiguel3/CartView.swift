//
//  CartView.swift
//  AbarrotesDonMiguel3
//
//  Created by Mariana Flores Sánchez on 29/04/25.
//
import SwiftUI

struct CartView: View {
    @EnvironmentObject var cartManager: CartManager
    @State private var showSuccess = false

    var body: some View {
        ZStack {
            LinearGradient(gradient: Gradient(colors: [Color.yellow.opacity(0.3), Color.red.opacity(0.3)]),
                           startPoint: .top,
                           endPoint: .bottom)
                .ignoresSafeArea()

            VStack {
                if cartManager.cart.isEmpty {
                    Text("¡Tu carrito está vacío!")
                        .font(.title2)
                        .fontWeight(.semibold)
                        .foregroundColor(.gray)
                        .padding()
                } else {
                    List {
                        ForEach(cartManager.cart, id: \.self) { product in
                            HStack {
                                Image(product.imageName)
                                    .resizable()
                                    .scaledToFit()
                                    .frame(width: 50, height: 50)
                                    .cornerRadius(10)

                                VStack(alignment: .leading) {
                                    Text(product.name)
                                        .font(.headline)
                                        .foregroundColor(.primary)
                                    Text(String(format: "$%.2f", product.price))
                                        .font(.subheadline)
                                        .foregroundColor(.secondary)
                                }

                                Spacer()

                                Button(action: {
                                    cartManager.removeFromCart(product)
                                }) {
                                    Image(systemName: "trash")
                                        .foregroundColor(.red)
                                        .padding(5)
                                }
                            }
                            .padding(.vertical, 10)
                            .background(Color("lightGreen"))
                            .cornerRadius(12)
                            .shadow(radius: 5)
                        }
                    }
                    .listStyle(PlainListStyle())

                    Text("Total: $\(cartManager.total(), specifier: "%.2f")")
                        .font(.title)
                        .fontWeight(.bold)
                        .padding()
                        .foregroundColor(.green)

                    Button("Finalizar compra") {
                        cartManager.finalizePurchase()
                        showSuccess = true
                    }
                    .buttonStyle(PrimaryButtonStyle())
                    .padding()
                    .alert(isPresented: $showSuccess) {
                        Alert(title: Text("Compra realizada"), message: Text("¡Gracias por tu compra!"), dismissButton: .default(Text("OK")))
                    }
                    .padding(.bottom)
                }
            }
            .navigationTitle("Carrito")
            .padding()
            .background(Color("lightYellow"))
            .cornerRadius(20)
            .shadow(radius: 10)
        }
    }
}
