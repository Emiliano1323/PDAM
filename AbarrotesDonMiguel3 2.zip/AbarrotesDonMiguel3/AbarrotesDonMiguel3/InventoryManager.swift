//
//  InventoryManager.swift
//  AbarrotesDonMiguel3
//
//  Created by Mariana Flores Sánchez on 04/05/25.
//
import Foundation

class InventoryManager: ObservableObject {
    @Published var products: [CartProduct] = [
        CartProduct(name: "Arroz", price: 25, imageName: "arroz"),
        CartProduct(name: "Frijol", price: 30, imageName: "frijol"),
        CartProduct(name: "Aceite", price: 50, imageName: "aceite"),
        CartProduct(name: "Papel higiénico", price: 40, imageName: "papel_higienico")
    ]

    func addProduct(_ product: CartProduct) {
        products.append(product)
    }

    func removeProduct(_ product: CartProduct) {
        if let index = products.firstIndex(of: product) {
            products.remove(at: index)
        }
    }
}

