//
//  InventoryManagementView.swift
//  AbarrotesDonMiguel3
//
//  Created by Mariana Flores Sánchez on 04/05/25.
//
import SwiftUI

struct InventoryManagementView: View {
    @EnvironmentObject var inventoryManager: InventoryManager
    @State private var newProductName = ""
    @State private var newProductPrice = ""
    @State private var newProductImage = ""
    @State private var searchQuery = ""

    // Filtro para productos según búsqueda
    var filteredProducts: [CartProduct] {
        if searchQuery.isEmpty {
            return inventoryManager.products
        } else {
            return inventoryManager.products.filter { $0.name.lowercased().contains(searchQuery.lowercased()) }
        }
    }

    var body: some View {
        ZStack {
            LinearGradient(gradient: Gradient(colors: [Color.yellow.opacity(0.3), Color.red.opacity(0.3)]),
                           startPoint: .top,
                           endPoint: .bottom)
                .ignoresSafeArea()

            VStack {
                // Título de la vista
                Text("Administrar Inventario")
                    .font(.title)
                    .fontWeight(.bold)
                    .foregroundColor(Color("MexicanRed"))
                    .padding(.top, 30)
                    .padding(.horizontal)

                VStack(spacing: 20) {
                    // Campo de texto para agregar un nuevo producto
                    TextField("Nombre del producto", text: $newProductName)
                        .textFieldStyle(RoundedBorderTextFieldStyle())
                        .padding()
                        .background(Color.white)
                        .cornerRadius(8)

                    TextField("Precio", text: $newProductPrice)
                        .keyboardType(.decimalPad)
                        .textFieldStyle(RoundedBorderTextFieldStyle())
                        .padding()
                        .background(Color.white)
                        .cornerRadius(8)

                    TextField("Imagen (nombre del archivo)", text: $newProductImage)
                        .textFieldStyle(RoundedBorderTextFieldStyle())
                        .padding()
                        .background(Color.white)
                        .cornerRadius(8)

                    Button("Agregar Producto") {
                        if let price = Double(newProductPrice), !newProductName.isEmpty, !newProductImage.isEmpty {
                            let newProduct = CartProduct(name: newProductName, price: price, imageName: newProductImage)
                            inventoryManager.addProduct(newProduct)
                            // Limpiar campos después de agregar
                            newProductName = ""
                            newProductPrice = ""
                            newProductImage = ""
                        }
                    }
                    .buttonStyle(PrimaryButtonStyle())
                    .padding()
                }

                Divider()
                    .padding()

                // Filtro de búsqueda
                TextField("Buscar Producto", text: $searchQuery)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                    .padding()
                    .background(Color.white)
                    .cornerRadius(8)
                    .padding(.horizontal)

                // ScrollView para los productos
                ScrollView {
                    VStack(spacing: 10) {
                        // Si no hay productos, mostrar un mensaje
                        if filteredProducts.isEmpty {
                            Text("No hay productos disponibles.")
                                .foregroundColor(.gray)
                                .padding()
                        }

                        // Mostrar lista de productos con opción de eliminar
                        ForEach(filteredProducts) { product in
                            HStack {
                                Image(product.imageName)
                                    .resizable()
                                    .scaledToFit()
                                    .frame(width: 80, height: 80)
                                    .cornerRadius(15)

                                VStack(alignment: .leading, spacing: 10) {
                                    Text(product.name)
                                        .font(.headline)
                                        .foregroundColor(.primary)

                                    Text(String(format: "$%.2f", product.price))
                                        .font(.subheadline)
                                        .foregroundColor(.secondary)
                                }

                                Spacer()

                                Button(action: {
                                    inventoryManager.removeProduct(product)
                                }) {
                                    Image(systemName: "trash")
                                        .foregroundColor(.red)
                                        .padding(5)
                                }
                            }
                            .padding()
                            .background(Color("lightGreen"))
                            .cornerRadius(15)
                            .shadow(radius: 5)
                        }
                    }
                    .padding()
                }
            }
            .padding()
            .background(Color("lightYellow"))
        }
    }
}
