//
//  User.swift
//  AbarrotesDonMiguel3
//
//  Created by Mariana Flores Sánchez on 29/04/25.
//
import Foundation

struct User {
    let username: String
    let password: String
}

